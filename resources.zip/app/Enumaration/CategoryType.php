<?php
namespace App\Enumaration;

class CategoryType
{
    /*
    table = user_meta_info
    column = status
    */
    public static $LIFE_STYLE = 1;
    public static $FASHION = 2;
    public static $SPORTS = 3;
    public static $MUSIC = 4;
    public static $HEALTH = 5;
    public static $TRAVEL = 6;
}
