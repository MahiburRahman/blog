<?php

namespace App\Model;
use Illuminate\Database\Eloquent\Model;
use DB;

class UserMetaInfo extends Model
{
    protected $table = 'user_meta_info';
    protected $guarded = [];

}
