<?php $__env->startSection('maincontent'); ?>
	<?php if(count($allPost)>0): ?>
		<?php $__currentLoopData = $allPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aPost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<article class="">
				<h2 class="">
					<a class="text-color" href="<?php echo e(route('single_post', $aPost->title)); ?>"><?php echo e(isset($aPost->title) ? $aPost->title : ''); ?></a>
				</h2> 				 
				<div class="">
					<ul class="post_time_ul">
						<li class="post_time_li"><b><?php echo e($aPost->created_at->format('h:ia d/m/Y')); ?> by </b></li>
						<li class="post_time_li"><b><?php echo e(isset($aPost->user->UserMeta->first_name) ? $aPost->user->UserMeta->first_name : ''); ?> <?php echo e(isset($aPost->user->UserMeta->last_name) ? $aPost->user->UserMeta->last_name : ''); ?></b></li>
					</ul>
				</div> 					 				
				<div class="">
					<?php if(strlen($aPost->text)>1000): ?>
						<?php echo e(mb_substr($aPost->text, 0, 1000)); ?>...
					<?php else: ?>
						<p><?php echo e(isset($aPost->text) ? $aPost->text : ''); ?></p>
					<?php endif; ?>
					
				</div> 
			</article>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<div class="pull-left">
			<?php echo e($allPost->links()); ?>

		</div>
	<?php else: ?>
		<div class="alert alert-danger text-center">There is no post</div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master.master_with_footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>