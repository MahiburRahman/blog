<?php
    $asset = asset('/');
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" href="<?php echo e($asset); ?>css/bootstrap.min.css">    
    <link rel="stylesheet" href="<?php echo e($asset); ?>css/telephonePlugin/intlTelInput.css">
	<link rel="stylesheet" href="<?php echo e($asset); ?>css/main.css?h=hhs">
    <link rel="stylesheet" href="<?php echo e($asset); ?>css/normalize.css">
    <link rel="stylesheet" href="<?php echo e($asset); ?>css/font-awesome.css">
    <link href='//fonts.googleapis.com/css?family=Open Sans' rel='stylesheet'>

    <?php echo $__env->yieldContent('additional_css'); ?>

</head>
<body>
	<div class="page-content">
		
        <div class="container">
            <div class="row">
                <div class="col-md-offset-4 col-md-4 ">
                    <div class="login-box">
                        <div class="login-box-header">
                            <img class="logo_property" src='<?php echo e($asset); ?>images/black_logo.png' height="70px" width="300px" alt=''>
                        </div>

                        <?php echo $__env->yieldContent('maincontent'); ?>

                    </div>
                </div>
            </div>
        </div>
    </div><br><br>
    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <script>window.jQuery || document.write('<script src="<?php echo e($asset); ?>js/vendor/jquery-1.12.1.min.js"><\/script>')</script>
    <script src="<?php echo e($asset); ?>js/bootstrap.min.js"></script>
    <script src="<?php echo e($asset); ?>js/telephonePlugin/intlTelInput.min.js"></script>
    <script src="<?php echo e($asset); ?>js/vendor/modernizr-2.8.3.min.js"></script>
    
    <?php echo $__env->yieldContent('additional_js'); ?>

</body>
</html>